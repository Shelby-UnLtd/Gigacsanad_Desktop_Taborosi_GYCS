﻿using KretaBasicSchoolSystem.Desktop.ViewModels.Base;

namespace KretaBasicSchoolSystem.Desktop.ViewModels.ControlPanel
{
    public class ControlPanelViewModel: BaseViewModel
    {
        public ControlPanelViewModel()
        {
                
        }
    }
}
